### XiaomiShop-
小米商城的部分静态页面，纯HTML和CSS编写。

适合用来熟悉HTML和CSS的一个小demo，全部敲完后感觉布局水平和HTML和CSS熟练度会有很大的提升。
